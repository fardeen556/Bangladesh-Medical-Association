/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package bangladesh.medical.association.Taznim;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class AdminHomepageController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    @FXML
    private void backOnClick(ActionEvent event) {
    }
    @FXML
    private void logOutOnClick(ActionEvent event) {
    }

    @FXML
    private void membershipManagementOnClick(ActionEvent event) {
    }

    @FXML
    private void eventCoordinationOnClick(ActionEvent event) {
    }

    @FXML
    private void financialManagementOnClick(ActionEvent event) {
    }

    @FXML
    private void communicationOutreachOnClick(ActionEvent event) {
    }

    @FXML
    private void hrmOnClick(ActionEvent event) {
    }

    @FXML
    private void regulatoryOnClick(ActionEvent event) {
    }

    @FXML
    private void managementMaintainanceOnClick(ActionEvent event) {
    }

    @FXML
    private void FeedbackOnClick(ActionEvent event) {
    }
    
}
