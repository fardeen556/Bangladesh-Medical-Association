/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package bangladesh.medical.association.Taznim;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class DoctorInformationController implements Initializable {

    @FXML
    private TableView<?> playerListTableView;
    @FXML
    private TableColumn<?, ?> doctorNameTableView;
    @FXML
    private TableColumn<?, ?> doctorIdTableView;
    @FXML
    private TableColumn<?, ?> speacilizedTableView;
    @FXML
    private TableColumn<?, ?> consultationHourTableView;
    @FXML
    private TableColumn<?, ?> contactTableView;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void backOnClick(ActionEvent event) {
    }

    @FXML
    private void logOutOnClick(ActionEvent event) {
    }
    
}
